const dados = getLocalStorageData();
gerarTabela(dados);